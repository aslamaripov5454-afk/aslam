﻿; =====================================================================
;  modules/categories.ahk — единая таксономия aslam
;  Один источник правды для меню, вкладки «Инструменты», палитры
;  команд, менеджера клавиш и справочника функций.
;  Запрещены свалки: «Инструменты», «Прочее», «Разное», «Клавиши v4».
; =====================================================================

; Порядок важен: он же порядок чипов и выпадающих фильтров.
global ASLAM_CATEGORY_LIST := [
    "Текст и редактура",
    "Код и разработка",
    "ИИ и нейросети",
    "Конвертеры и расчёты",
    "Время и продуктивность",
    "Система и производительность",
    "Окна и управление",
    "Сеть и интернет",
    "Файлы и проводник",
    "Медиа и звук",
    "Генераторы и автоматизация",
    "Телефон и связь",
    "Справка и настройки"
]

AslamCategories() {
    ; Копия: вызывающий код не должен менять эталонный порядок.
    return ASLAM_CATEGORY_LIST.Clone()
}

; ---------- Короткие подписи для чипов 114 px ----------
AslamCategoryShort(name) {
    static m := Map(
        "Текст и редактура", "Текст",
        "Код и разработка", "Код",
        "ИИ и нейросети", "ИИ",
        "Конвертеры и расчёты", "Конвертеры",
        "Время и продуктивность", "Время",
        "Система и производительность", "Система",
        "Окна и управление", "Окна",
        "Сеть и интернет", "Сеть",
        "Файлы и проводник", "Файлы",
        "Медиа и звук", "Медиа",
        "Генераторы и автоматизация", "Генераторы",
        "Телефон и связь", "Телефон",
        "Справка и настройки", "Справка"
    )
    return m.Has(name) ? m[name] : name
}

; ---------- Иконки: новые категории берут существующие 3D-иконки ----------
AslamCategoryIcon(name) {
    static m := Map(
        "Текст и редактура", "Текст",
        "Код и разработка", "Код",
        "ИИ и нейросети", "ИИ-шаблоны",
        "Конвертеры и расчёты", "Конвертеры",
        "Время и продуктивность", "Время",
        "Система и производительность", "Система",
        "Окна и управление", "Окна",
        "Сеть и интернет", "Сеть",
        "Файлы и проводник", "Файлы",
        "Медиа и звук", "Медиа",
        "Генераторы и автоматизация", "Автоматизация"
    )
    if m.Has(name) {
        rel := "tools\group_" m[name] ".png"
        if FileExist(A_ScriptDir "\assets\" rel)
            return rel
    }
    ; У «Телефон и связь» и «Справка и настройки» групповых иконок нет.
    return (name = "Телефон и связь") ? "icon_phone.png" : "icon_settings.png"
}

; ---------- Нормализация старых названий ----------
; Единственное место, где живут старые метки.
AslamNormalizeCategory(name, fallback := "Справка и настройки") {
    static legacy := Map(
        "текст", "Текст и редактура",
        "правка", "Текст и редактура",
        "код", "Код и разработка",
        "c++", "Код и разработка",
        "разработка", "Код и разработка",
        "ии", "ИИ и нейросети",
        "ии-шаблоны", "ИИ и нейросети",
        "конвертеры", "Конвертеры и расчёты",
        "время", "Время и продуктивность",
        "система", "Система и производительность",
        "окна", "Окна и управление",
        "рабочие столы", "Окна и управление",
        "меню", "Окна и управление",
        "программы", "Окна и управление",
        "клавиши", "Окна и управление",
        "сеть", "Сеть и интернет",
        "youtube", "Сеть и интернет",
        "файлы", "Файлы и проводник",
        "медиа", "Медиа и звук",
        "звук", "Медиа и звук",
        "генераторы", "Генераторы и автоматизация",
        "автоматизация", "Генераторы и автоматизация",
        "телефон", "Телефон и связь",
        "справка", "Справка и настройки",
        "интерфейс", "Справка и настройки",
        "своё", "Справка и настройки",
        "свое", "Справка и настройки",
        "v4", "Справка и настройки",
        "клавиши v4", "Справка и настройки",
        "инструменты", "Справка и настройки",
        "прочее", "Справка и настройки",
        "разное", "Справка и настройки"
    )
    s := Trim(StrReplace(String(name), Chr(0xFEFF), ""))
    ; «Текст и редактура (12)» → «Текст и редактура»
    if RegExMatch(s, "^(.*?)\s*\(\d+\)$", &m)
        s := Trim(m[1])
    if (s = "" || s = "Все категории" || s = "Все группы")
        return fallback
    for c in ASLAM_CATEGORY_LIST
        if (s = c)
            return c
    key := StrLower(s)
    return legacy.Has(key) ? legacy[key] : fallback
}

; Точечные исправления: инструмент лежал не в своей категории.
AslamCategoryForTool(fnName) {
    static over := Map(
        "ToolIpInfo", "Сеть и интернет",
        "ToolClipToFile", "Файлы и проводник",
        "ToolToggleHidden", "Файлы и проводник",
        "ToolEmptyRecycle", "Файлы и проводник",
        "ToolColorPicker", "Медиа и звук",
        "ToolRomanNumeral", "Конвертеры и расчёты",
        "ToolNumberToWords", "Конвертеры и расчёты",
        "ToolBackupSettings", "Справка и настройки",
        "ToolScheduler", "Время и продуктивность",
        "ToolSysInfo", "Система и производительность",
        "ToolOpenStartup", "Система и производительность",
        "PhoneLinkRing", "Телефон и связь"
    )
    return over.Has(fnName) ? over[fnName] : ""
}

AslamToolCategoryOf(d) {
    ; d = [функция, название, описание, клавиши, группа, цвет, ...]
    fix := IsObject(d) ? AslamCategoryForTool(d[1]) : ""
    if (fix != "")
        return fix
    return AslamNormalizeCategory(IsObject(d) ? d[5] : "", "Окна и управление")
}

; ---------- Счётчики и элементы фильтров ----------
AslamCategoryCounts() {
    counts := Map()
    for c in ASLAM_CATEGORY_LIST
        counts[c] := 0
    for d in AslamToolDefs()
        counts[d[5]] += 1
    return counts
}

AslamCategoryCountsForRows(rows) {
    counts := Map()
    for c in ASLAM_CATEGORY_LIST
        counts[c] := 0
    for r in rows
        if (IsObject(r) && r.Length >= 3 && counts.Has(r[3]))
            counts[r[3]] += 1
    return counts
}

AslamCategoryFilterItems(counts := "") {
    ; «Все категории», затем «Категория (N)» по порядку таксономии.
    items := ["Все категории"]
    for c in ASLAM_CATEGORY_LIST {
        n := 0
        if (IsObject(counts) && counts.Has(c))
            n := counts[c]
        items.Push(c " (" n ")")
    }
    return items
}

AslamCategoryFromLabel(text) {
    s := Trim(StrReplace(String(text), Chr(0xFEFF), ""))
    if (s = "" || s = "Все категории" || s = "Все группы")
        return ""
    if RegExMatch(s, "^(.*?)\s*\(\d+\)$", &m)
        s := Trim(m[1])
    for c in ASLAM_CATEGORY_LIST
        if (s = c)
            return c
    return AslamNormalizeCategory(s)
}

AslamCategoryDDLFill(ddl, counts := "") {
    ; Пересобирает выпадающий список, сохраняя выбранную категорию.
    try {
        old := AslamCategoryFromLabel(ddl.Text)
        ddl.Delete()
        ddl.Add(AslamCategoryFilterItems(counts))
        ddl.Value := 1
        if (old != "") {
            items := AslamCategoryFilterItems(counts)
            Loop items.Length {
                if (AslamCategoryFromLabel(items[A_Index]) = old) {
                    ddl.Value := A_Index
                    break
                }
            }
        }
    }
}

; ---------- Самопроверка ----------
_AslamCategoriesSelfTest() {
    AslamAssertEq(AslamCategories().Length, 13, "13 смысловых категорий")
    AslamAssertEq(AslamNormalizeCategory("Текст"), "Текст и редактура", "старая метка «Текст»")
    AslamAssertEq(AslamNormalizeCategory("Инструменты"), "Справка и настройки", "нет свалки «Инструменты»")
    AslamAssertEq(AslamNormalizeCategory("Клавиши v4"), "Справка и настройки", "нет свалки «Клавиши v4»")
    AslamAssertEq(AslamNormalizeCategory("Текст и редактура (7)"), "Текст и редактура", "метка со счётчиком")
    AslamAssertEq(AslamCategoryFromLabel("Все категории"), "", "сброс фильтра")
    bad := ""
    for d in AslamToolDefs()
        if (d[5] = "Инструменты" || d[5] = "Прочее" || d[5] = "Разное" || InStr(d[5], "v4"))
            bad .= d[1] " "
    AslamAssert(bad = "", "нет инструментов в категориях-свалках", bad)
    AslamAssertEq(AslamCategoryCounts()["Текст и редактура"] > 0, true, "счётчик текста не пуст")
}

