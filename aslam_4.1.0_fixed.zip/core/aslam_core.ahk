﻿; =====================================================================
;  core/aslam_core.ahk — версия, пути, настройки и защита секретов
;  AutoHotkey v2.0.x (проверено на синтаксисе v2.0.31)
;  Подключается первым: #Include "core\aslam_core.ahk"
; =====================================================================

; ---------- 0. Единый источник правды о версии ----------
; Менять ТОЛЬКО здесь. Все заголовки, трей, диагностика и документы
; берут версию отсюда (см. tools/build_release.py — он сверяет файлы).
global ASLAM_VERSION := "4.1.0"
global ASLAM_BUILD := "20261123"
global ASLAM_CHANNEL := "stable"

AslamVersionText() => "aslam v" ASLAM_VERSION
AslamVersionFull() => "aslam v" ASLAM_VERSION " (build " ASLAM_BUILD ", " ASLAM_CHANNEL ")"

; ---------- 1. Каталог настроек ----------
; Новый дом: %APPDATA%\aslam. Старый %APPDATA%\AutoHotkeyPro мягко
; импортируется один раз, пользовательские файлы не перезаписываются.
AslamConfigDir() {
    dir := A_AppData "\aslam"
    try DirCreate(dir)
    if DirExist(dir)
        return dir
    ; Крайний случай: профиль только для чтения — падаем в Документы.
    dir := A_MyDocuments "\AutoHotkey"
    try DirCreate(dir)
    return dir
}

AslamLegacyConfigDir() => A_AppData "\AutoHotkeyPro"

AslamConfigMigrate(scriptDir, cfgDir) {
    ; Возвращает число скопированных файлов. Никогда не перезаписывает
    ; существующие файлы нового каталога и не удаляет старые.
    files := ["settings.ini", "hotkeys.ini", "slovar.txt", "tg_schedule.txt", "cpp_test.ini"]
    copied := 0
    legacy := AslamLegacyConfigDir()
    for f in files {
        dst := cfgDir "\" f
        if FileExist(dst)
            continue
        for srcDir in [legacy, scriptDir] {
            src := srcDir "\" f
            if !FileExist(src)
                continue
            try {
                FileCopy(src, dst, 0)
                copied += 1
            } catch as e {
                AslamLog("WARN", "config", "импорт " f ": " e.Message)
            }
            break
        }
    }
    ; Метка переноса: диагностика показывает, откуда пришли настройки.
    if (copied > 0 && !FileExist(cfgDir "\migrated_from.txt")) {
        try FileAppend("AutoHotkeyPro -> aslam, " FormatTime(, "yyyy-MM-dd HH:mm") "`n", cfgDir "\migrated_from.txt", "UTF-8")
    }
    return copied
}

; ---------- 2. Типизированное чтение settings.ini ----------
AslamIniStr(file, sec, key, def := "") {
    try {
        v := IniRead(file, sec, key, def)
        return (v = "") ? def : v
    } catch
        return def
}

AslamIniBool(file, sec, key, def := false) {
    v := StrLower(Trim(AslamIniStr(file, sec, key, def ? "1" : "0")))
    return (v = "1" || v = "true" || v = "yes" || v = "on" || v = "да")
}

AslamIniInt(file, sec, key, def, lo, hi) {
    raw := Trim(AslamIniStr(file, sec, key, String(def)))
    if !RegExMatch(raw, "^-?\d+$")
        return def
    v := Integer(raw)
    if (v < lo)
        return lo
    if (v > hi)
        return hi
    return v
}

; ---------- 3. Безопасная запись настроек ----------
; IniWrite не атомарен. Перед первой записью в файл за сеанс делаем
; резервную копию, а ошибку записи не глотаем, а журналируем.
AslamIniWrite(file, sec, key, val) {
    static touched := Map()
    try {
        if (!touched.Has(file)) {
            touched[file] := true
            if FileExist(file)
                try FileCopy(file, file ".bak", 1)
        }
        IniWrite(val, file, sec, key)
        return true
    } catch as e {
        try AslamLog("ERROR", "config", AslamRedact("запись [" sec "] " key ": " e.Message))
        return false
    }
}

AslamConfigBackup(tag := "manual") {
    ; Копия всех настроек в Документы\aslam_backup\<дата-время>.
    src := AslamConfigDir()
    stamp := FormatTime(, "yyyyMMdd-HHmmss")
    dst := A_MyDocuments "\aslam_backup\" stamp "_" tag
    try DirCreate(dst)
    n := 0
    for f in ["settings.ini", "hotkeys.ini", "slovar.txt", "tg_schedule.txt", "cpp_test.ini", "aslam_v4.log"] {
        p := src "\" f
        if FileExist(p) {
            try {
                FileCopy(p, dst "\" f, 1)
                n += 1
            }
        }
    }
    return {Dir: dst, Count: n}
}

AslamIniWriteMany(file, pairs) {
    ; Атомарная по смыслу запись: резервная копия → все ключи → откат при сбое.
    ; pairs = [[раздел, ключ, значение], ...]
    backup := file ".bak"
    had := FileExist(file) ? true : false
    if had
        try FileCopy(file, backup, 1)
    try {
        for p in pairs
            IniWrite(p[3], file, p[1], p[2])
        return true
    } catch as e {
        if had
            try FileCopy(backup, file, 1)
        try AslamLog("ERROR", "config", AslamRedact("настройки не сохранены: " e.Message))
        return false
    }
}

; ---------- 4. Маскирование секретов ----------
; Вызывается из LogError, AslamLog и всех сообщений об ошибках ИИ.
; Ключи в настройках хранятся как dpapi:<base64>, их тоже прячем.
AslamRedact(text) {
    s := (text = "" || !IsSet(text)) ? "" : String(text)
    if (s = "")
        return ""
    s := RegExReplace(s, "i)(authorization\s*[:=]\s*bearer\s+)[^\s,;`"']+", "$1***")
    s := RegExReplace(s, "i)((?:api[_-]?key|apikey|x-api-key|access[_-]?token|refresh[_-]?token|token|secret|password|passwd|pwd)\s*[:=]\s*)[^\s,;&`"']+", "$1***")
    s := RegExReplace(s, "i)([?&](?:key|api_key|apikey|access_token|token)=)[^&\s]+", "$1***")
    s := RegExReplace(s, "\bAIza[0-9A-Za-z_\-]{20,}", "AIza***")
    s := RegExReplace(s, "\bgsk_[0-9A-Za-z_\-]{10,}", "gsk_***")
    s := RegExReplace(s, "\bsk-[0-9A-Za-z_\-]{10,}", "sk-***")
    s := RegExReplace(s, "\b(?:gsk|sk|xai)-[A-Za-z0-9_\-]{8,}", "***")
    s := RegExReplace(s, "dpapi:[A-Za-z0-9+/=]+", "dpapi:***")
    return s
}

AslamSafeMsg(e) {
    ; Единая точка для текста исключения: без ключей, без путей профиля.
    msg := IsObject(e) ? e.Message : String(e)
    return AslamRedact(msg)
}

; ---------- 5. Самопроверка модуля ----------
_AslamFoundationSelfTest() {
    AslamAssertEq(StrLen(ASLAM_VERSION) > 0, true, "ASLAM_VERSION задан")
    AslamAssertEq(RegExMatch(ASLAM_BUILD, "^\d{8}$") = 1, true, "ASLAM_BUILD в формате yyyyMMdd")
    AslamAssertEq(InStr(AslamVersionText(), ASLAM_VERSION) > 0, true, "версия в подписи")
    AslamAssertEq(AslamRedact("Authorization: Bearer abc123def"), "Authorization: Bearer ***", "маскировка Bearer")
    AslamAssertEq(AslamRedact("?key=AIza1234567890abcdefghij"), "?key=***", "маскировка key в URL")
    AslamAssertEq(AslamRedact("GEMINI_API_KEY=AIzaSyD-1234567890abcdefghij"), "GEMINI_API_KEY=***", "маскировка *_API_KEY")
    AslamAssertEq(AslamRedact("ключ dpapi:QUJDRA=="), "ключ dpapi:***", "маскировка dpapi")
    AslamAssertEq(AslamRedact("обычный текст про ключи"), "обычный текст про ключи", "обычный текст не портится")
}
