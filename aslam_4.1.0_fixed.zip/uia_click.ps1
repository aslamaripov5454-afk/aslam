﻿<#
  aslam: uia_click.ps1 — надёжный клик по кнопке окна через UI Automation.
  Коды возврата:
    0 — действие выполнено (паттерн UIA или физический клик);
    1 — окно не найдено за отведённое время;
    2 — окно найдено, но нужный элемент не найден/недоступен;
    3 — неверные параметры (пустые шаблоны, плохой regex, отрицательный таймаут).

  Особенности:
    * -LiteralMatch $true (по умолчанию): шаблон — не regex, а текст.
      Спецсимволы экранируются; вертикальная черта остаётся разделителем
      вариантов: "Позвонить|Ring" = «Позвонить» ИЛИ «Ring».
    * -ProcessName ограничивает поиск процессом целевого окна
      (например, "PhoneExperienceHost" для Phone Link).
    * Per-Monitor DPI Awareness: SetProcessDpiAwarenessContext(-4),
      фолбэк SetProcessDPIAware() для Windows < 10 1703.
    * Курсор пользователя возвращается на место после физического клика.
#>
[CmdletBinding()]
param(
    [string]$WinRx,
    [string]$BtnRx,
    [int]$Timeout = 15,
    [string]$ProcessName = "",
    [bool]$LiteralMatch = $true,
    [switch]$NoRestoreCursor,
    [switch]$Quiet
)

$ErrorActionPreference = 'Stop'

function Exit-With([int]$code, [string]$message) {
    if (-not $Quiet -and $message) { [Console]::Error.WriteLine($message) }
    exit $code
}

if ([string]::IsNullOrWhiteSpace($WinRx) -or [string]::IsNullOrWhiteSpace($BtnRx)) {
    Exit-With 3 "aslam/uia: пустой -WinRx или -BtnRx"
}
if ($Timeout -lt 1)  { $Timeout = 1 }
if ($Timeout -gt 120) { $Timeout = 120 }
if ($LiteralMatch -and $ProcessName -match '[*?]') {
    Exit-With 3 "aslam/uia: в -ProcessName недопустимы подстановочные знаки"
}

function Convert-Pattern([string]$pattern, [bool]$literal) {
    if ([string]::IsNullOrEmpty($pattern)) { return '' }
    if (-not $literal) {
        try { [void][regex]::new($pattern); return $pattern }
        catch { Exit-With 3 "aslam/uia: некорректное регулярное выражение: $pattern" }
    }
    $parts = $pattern -split '\|'
    $escaped = foreach ($p in $parts) { [regex]::Escape($p.Trim()) }
    $expr = ($escaped -join '|')
    try { [void][regex]::new($expr) } catch { Exit-With 3 "aslam/uia: некорректный шаблон: $pattern" }
    return $expr
}

$winExpr = Convert-Pattern $WinRx $LiteralMatch
$btnExpr = Convert-Pattern $BtnRx $LiteralMatch

Add-Type -AssemblyName UIAutomationClient, UIAutomationTypes

if (-not ('AslamUiaNative' -as [type])) {
Add-Type @"
using System;
using System.Runtime.InteropServices;
public static class AslamUiaNative {
    [StructLayout(LayoutKind.Sequential)] public struct POINT { public int X; public int Y; }

    [DllImport("user32.dll", SetLastError = true)]
    public static extern bool SetProcessDpiAwarenessContext(IntPtr value);
    [DllImport("user32.dll")] public static extern bool SetProcessDPIAware();
    [DllImport("user32.dll")] public static extern bool GetCursorPos(out POINT p);
    [DllImport("user32.dll")] public static extern bool SetCursorPos(int x, int y);
    [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr hWnd);
    [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
    [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint pid);
    [DllImport("user32.dll")] public static extern void mouse_event(uint flags, uint dx, uint dy, uint data, UIntPtr extra);
    [DllImport("user32.dll")] public static extern bool IsWindow(IntPtr hWnd);

    public static bool MakeDpiAware() {
        try { if (SetProcessDpiAwarenessContext(new IntPtr(-4))) return true; } catch { }
        try { return SetProcessDPIAware(); } catch { return false; }
    }
    public static void ClickAt(int x, int y) {
        SetCursorPos(x, y);
        System.Threading.Thread.Sleep(60);
        mouse_event(0x0002, 0, 0, 0, UIntPtr.Zero); // LEFTDOWN
        mouse_event(0x0004, 0, 0, 0, UIntPtr.Zero); // LEFTUP
    }
}
"@
}

# DPI awareness обязательна ДО первого обращения к UIA: иначе координаты
# BoundingRectangle и курсора живут в разных системах при 125/150%.
[void][AslamUiaNative]::MakeDpiAware()

$AE = [System.Windows.Automation.AutomationElement]
$root = $AE::RootElement

$controlTypes = @(
    [System.Windows.Automation.ControlType]::Button,
    [System.Windows.Automation.ControlType]::Hyperlink,
    [System.Windows.Automation.ControlType]::MenuItem,
    [System.Windows.Automation.ControlType]::ListItem,
    [System.Windows.Automation.ControlType]::TabItem
)

function Test-NameMatch($element, [string]$expr) {
    try {
        $name = $element.Current.Name
        if ([string]::IsNullOrWhiteSpace($name)) { return $false }
        return ($name -match $expr)
    } catch { return $false }
}

function Test-ProcessMatch($element, [string]$procName) {
    if ([string]::IsNullOrWhiteSpace($procName)) { return $true }
    try {
        $hwnd = [IntPtr]$element.Current.NativeWindowHandle
        if ($hwnd -eq [IntPtr]::Zero) { return $false }
        [uint32]$targetPid = 0
        [void][AslamUiaNative]::GetWindowThreadProcessId($hwnd, [ref]$targetPid)
        if ($targetPid -eq 0) { return $false }
        $p = Get-Process -Id $targetPid -ErrorAction Stop
        return ($p.ProcessName -eq $procName -or $p.ProcessName -like "$procName*")
    } catch { return $false }
}

function Invoke-Element($element, [IntPtr]$hwnd) {
    # 1. InvokePattern — «нажать» без мыши.
    try {
        $p = $null
        if ($element.TryGetCurrentPattern([System.Windows.Automation.InvokePattern]::Pattern, [ref]$p)) {
            ([System.Windows.Automation.InvokePattern]$p).Invoke()
            return $true
        }
    } catch { }

    # 2. TogglePattern — переключатели (mute, вкл/выкл).
    try {
        $p = $null
        if ($element.TryGetCurrentPattern([System.Windows.Automation.TogglePattern]::Pattern, [ref]$p)) {
            ([System.Windows.Automation.TogglePattern]$p).Toggle()
            return $true
        }
    } catch { }

    # 3. SelectionItemPattern — вкладки, пункты списков.
    try {
        $p = $null
        if ($element.TryGetCurrentPattern([System.Windows.Automation.SelectionItemPattern]::Pattern, [ref]$p)) {
            ([System.Windows.Automation.SelectionItemPattern]$p).Select()
            return $true
        }
    } catch { }

    # 4. LegacyIAccessiblePattern.DoDefaultAction — старые Win32-кнопки.
    try {
        $p = $null
        if ($element.TryGetCurrentPattern([System.Windows.Automation.LegacyIAccessiblePattern]::Pattern, [ref]$p)) {
            ([System.Windows.Automation.LegacyIAccessiblePattern]$p).DoDefaultAction()
            return $true
        }
    } catch { }

    # 5. Физический клик по центру с сохранением позиции курсора.
    try {
        $rect = $element.Current.BoundingRectangle
        if ($rect.Width -le 0 -or $rect.Height -le 0) { return $false }
        if ($rect.IsEmpty) { return $false }
        $cx = [int]($rect.Left + $rect.Width / 2)
        $cy = [int]($rect.Top + $rect.Height / 2)

        $saved = New-Object AslamUiaNative+POINT
        $hasSaved = [AslamUiaNative]::GetCursorPos([ref]$saved)

        if ($hwnd -ne [IntPtr]::Zero -and [AslamUiaNative]::IsWindow($hwnd)) {
            [void][AslamUiaNative]::SetForegroundWindow($hwnd)
            Start-Sleep -Milliseconds 140
        }
        [AslamUiaNative]::ClickAt($cx, $cy)
        Start-Sleep -Milliseconds 90

        if ($hasSaved -and -not $NoRestoreCursor) {
            [void][AslamUiaNative]::SetCursorPos($saved.X, $saved.Y)
        }
        return $true
    } catch { return $false }
}

$deadline = (Get-Date).AddSeconds($Timeout)
$windowSeen = $false
$lastError = ""

while ((Get-Date) -lt $deadline) {
    try {
        $windows = $root.FindAll([System.Windows.Automation.TreeScope]::Children, [System.Windows.Automation.Condition]::TrueCondition)
    } catch {
        $windows = @()
    }

    foreach ($w in $windows) {
        try {
            if (-not (Test-NameMatch $w $winExpr)) { continue }
            if (-not (Test-ProcessMatch $w $ProcessName)) { continue }
            $windowSeen = $true
            $hwnd = [IntPtr]$w.Current.NativeWindowHandle

            foreach ($type in $controlTypes) {
                $cond = New-Object System.Windows.Automation.PropertyCondition($AE::ControlTypeProperty, $type)
                $items = $w.FindAll([System.Windows.Automation.TreeScope]::Descendants, $cond)
                foreach ($e in $items) {
                    try {
                        if (-not (Test-NameMatch $e $btnExpr)) { continue }
                        if (-not $e.Current.IsEnabled) { continue }
                        if ($e.Current.IsOffscreen) { continue }
                        if (Invoke-Element $e $hwnd) { exit 0 }
                    } catch { $lastError = $_.Exception.Message }
                }
            }
        } catch {
            $lastError = $_.Exception.Message
            continue
        }
    }
    Start-Sleep -Milliseconds 350
}

if (-not $windowSeen) {
    Exit-With 1 "aslam/uia: окно не найдено ($WinRx)"
}
$suffix = ""
if ($lastError) { $suffix = " ($lastError)" }
Exit-With 2 "aslam/uia: элемент не найден или недоступен ($BtnRx)$suffix"
