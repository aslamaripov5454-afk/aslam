# aslam 4.1.0 (3D Menu & Laptop Anti-Lag Edition) — полный отчёт исправлений

Проверено анализатором `tools/aslam_check.py`: **ОШИБОК: 0 · ПРЕДУПРЕЖДЕНИЙ: 0**.

## Что было сломано в исходном архиве и что исправлено

1. **Папка `assets\3d\` в архиве была полностью пустой (0 файлов).**
   - Из-за этого `Aslam3DHeader()`, `Aslam3DSidebar()`, `Aslam3DDashBanner()` ничего не рисовали, диагностика выдавала `⚠ включено, но нет папки assets\3d`, а самопроверка `_AslamUiSelfTest()` падала на светлой теме.
   - **Исправлено:** отрендерены все 24 3D-шапки и 3D-сайдбары (`header_*.png`, `header_light_*.png`, `sidebar_*.png`, `sidebar_light_*.png`) для всех 6 цветов акцента (`blue`, `purple`, `emerald`, `orange`, `pink`, `cyan`).

2. **В архиве отсутствовала папка `assets\sounds\` и звук `error.wav`.**
   - При вызове `AslamSound("error")` (при `kind = "err"`) и любых звуков уведомлений файлы не находились.
   - **Исправлено:** синтезированы и упакованы все 14 студийных WAV-звуков (44 100 Гц, 16 бит PCM) в `assets\sounds\` (`ok.wav`, `warn.wav`, `error.wav`, `alarm.wav`, `bell.wav`, `dice.wav`, `startup.wav`, `click.wav`, `toggle.wav`, `open.wav`, `close.wav`, `select.wav`, `scroll.wav`, `antilag.wav`) + новый пространственный звук заставки `assets\aslam_start.wav`.

3. **Битая кодировка CP866 у русских имён файлов в `assets\tools\group_*.png` и 0 иконок инструментов.**
   - В исходном архиве имена `group_Текст.png` и др. были повреждены (`group_.png`), а индивидуальные иконки инструментов `assets\tools\Tool*.png` отсутствовали (`0 / 96` в диагностике).
   - **Исправлено:** пересозданы все 14 групповых 3D-иконок `group_*.png` с чистыми UTF-8 именами и сгенерированы все 3D-иконки инструментов в `assets\tools\`.

4. **Отсутствовали `assets\aslam.ico` и `assets\app.ico`, а на заставке `aslam_splash2.png` оставалась старая надпись `v4.0-beta3`.**
   - **Исправлено:** сгенерированы многослойные `.ico` (16–256 px) для системного трея и новые 3D-заставки `aslam_splash2.png` (1280×720) / `aslam_splash2_s.png` (640×360) с версией `v4.1.0`.

5. **Старый путь `%APPDATA%\AutoHotkeyPro` в `BuildDashSettings()` и `ToolBackupSettings()`.**
   - Кнопка «Папка настроек» открывала старую папку вместо `%APPDATA%\aslam`.
   - **Исправлено:** везде используется `AslamConfigDir()` (`%APPDATA%\aslam`).

6. **Новое 3D-меню (`Show3DToolsMenu`) и 3D-объём во всех всплывающих меню (`CppSchoolMenu`, `CppSnippets`, `AiPanel`).**
   - Во всех меню включены 3D-шапки, верхние блики, нижние фаски, акцентные грани и тактильная озвучка (`open.wav`, `click.wav`, `select.wav`, `close.wav`).

7. **Новый модуль «⚡ Антилаг ноутбука» (`ToolAntiLag`, `ShowAntiLagPanel`, `AslamAntiLagNow`, фоновый сторож `_AslamAntiLagWatchdog`).**
   - Горячая клавиша: **`Ctrl+Alt+Shift+L`** (1 нажатие — мгновенно отвиснуть, 2 нажатия — открыть панель Антилага) и аккорд **`Ctrl+Alt+Z → 4 → L`**.
   - Снимает залипание клавиш (`ReleaseMods`) и блокировку буфера обмена (`CloseClipboard`), находит зависшие окна (`IsHungAppWindow`), перезапускает зависший Проводник (`explorer.exe`), повышает приоритет активного окна, переводит тяжёлые фоновые процессы (>180 МБ) на `BelowNormal` и освобождает ОЗУ (`EmptyWorkingSet`).
   - Фоновый сторож каждые 4 секунды отслеживает микрофризы ноутбука и переполнение ОЗУ (≥ 88%) и автоматически разгружает систему.
