# aslam 4.1.0 — исправления

Проверено 23.11.2026.

## Что было сломано

1. **В архиве отсутствовал `modules\categories.ahk`.**
   `aslam.ahk` содержит `#Include "modules\categories.ahk"`, поэтому исходная версия не запускалась вообще:
   `#Include file "modules\categories.ahk" cannot be opened.`

2. **`core\aslam_core.ahk`, функция `AslamRedact()` — синтаксис AHK v1.**
   В регулярных выражениях использовалось удвоение кавычек `""`:
   `[^\s,;""']+` и `[^\s,;&""']+`.
   В AutoHotkey v2 так нельзя, кавычка экранируется обратным апострофом: `` `" ``.
   Ошибка: `Missing space or operator before this`.

3. **То же самое в собранном `dist\aslam.ahk`** (строки 164–165).

## Что сделано

- `modules\categories.ahk` восстановлен из собранного `dist\aslam.ahk` (блок между маркерами
  `begin/end modules/categories.ahk`): список 13 категорий, `AslamCategories()`,
  `AslamCategoryShort()`, `AslamCategoryIcon()`, `AslamNormalizeCategory()`,
  `AslamCategoryForTool()`, счётчики, фильтры и самопроверка.
- В `core\aslam_core.ahk` и `dist\aslam.ahk` удвоенные кавычки заменены на `` `" ``.
- Ничего другого в коде не менялось.

## Проверка

- `AutoHotkey64.exe /ErrorStdOut /validate aslam.ahk` — 0 ошибок.
- `AutoHotkey64.exe /ErrorStdOut /validate dist\aslam.ahk` — 0 ошибок.
- Запуск `aslam.ahk`: stderr пуст, журнал `%APPDATA%\aslam\aslam_v4.log`:
  `aslam v4.1.0 старт: масштаб 1×, тема dark, язык ru`, `включено клавиш v4: 25`, ошибок нет.
- Запуск `dist\aslam.ahk`: stderr пуст, старт без ошибок.

## Как запускать

Основной файл: `aslam.ahk` (рядом должны лежать `core\`, `modules\`, `lib\`, `assets\`, `uia_click.ps1`).

Одним файлом: `dist\aslam.ahk` — положить его в корень папки, где лежат `assets\` и `uia_click.ps1`.
