#!/usr/bin/env python3
import os, re, sys, base64, wave

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

def strip_comment(line):
    idx = line.find(" ;")
    if idx != -1:
        return line[:idx]
    if line.lstrip().startswith(";"):
        return ""
    return line

def check_project():
    errors = []
    warnings = []

    ahk_files = [
        os.path.join(ROOT, "core", "aslam_core.ahk"),
        os.path.join(ROOT, "modules", "categories.ahk"),
        os.path.join(ROOT, "lib", "aslam_assets_data.ahk"),
        os.path.join(ROOT, "aslam.ahk"),
        os.path.join(ROOT, "dist", "aslam.ahk"),
    ]

    for p in ahk_files:
        if not os.path.exists(p):
            errors.append(f"Отсутствует файл: {p}")
            continue
        with open(p, "r", encoding="utf-8") as f:
            lines = f.readlines()
        for idx, line in enumerate(lines, 1):
            code = strip_comment(line)
            if len(line) > 20050:
                warnings.append(f"{os.path.basename(p)}:{idx} строка длиннее 20000 символов ({len(line)})")
            if "A_LocalAppData" in code:
                errors.append(f"{os.path.basename(p)}:{idx} переменная A_LocalAppData (только AHK v2.1)")
            if '""\']+' in code:
                errors.append(f"{os.path.basename(p)}:{idx} синтаксис удвоения кавычек AHK v1")

    combined = ""
    for p in ahk_files[:4]:
        with open(p, "r", encoding="utf-8") as f:
            combined += "\n" + f.read()

    hotif_open = False
    with open(os.path.join(ROOT, "aslam.ahk"), "r", encoding="utf-8") as f:
        for idx, line in enumerate(f, 1):
            s = strip_comment(line).strip()
            if s.startswith("#HotIf"):
                arg = s[6:].strip()
                hotif_open = bool(arg)
    if hotif_open:
        errors.append("Незакрытый блок #HotIf в конце aslam.ahk")

    tool_defs = re.findall(r'\[\s*"((?:Tool|PhoneLink)[A-Za-z0-9_]+)"\s*,\s*"([^"]+)"\s*,\s*"([^"]*)"\s*,\s*"([^"]*)"\s*,\s*"([^"]+)"', combined)
    unique_tools = {}
    for fn, title, desc, hk, grp in tool_defs:
        unique_tools[fn] = (title, desc, hk, grp)

    help_cards = set(re.findall(r'd\.Push\(\[\s*"([A-Za-z0-9_]+)"', combined))
    chords = set(re.findall(r'"[0-9DF]:[A-Za-z0-9]+"\s*,\s*"([A-Za-z0-9_]+)"', combined))

    for fn, (title, desc, hk, grp) in unique_tools.items():
        if not re.search(rf'^\s*{re.escape(fn)}\s*\(', combined, re.M):
            errors.append(f"Инструмент {fn} не имеет функции реализации")
        if fn not in help_cards:
            errors.append(f"Инструмент {fn} не имеет карточки справки в _AslamHelpData")
        if not hk and fn not in chords:
            errors.append(f"Инструмент {fn} не имеет ни прямой клавиши, ни аккорда")
        ico_p = os.path.join(ROOT, "assets", "tools", f"{fn}.png")
        if not os.path.exists(ico_p):
            errors.append(f"Отсутствует 3D-иконка инструмента: assets/tools/{fn}.png")

    with open(os.path.join(ROOT, "lib", "aslam_assets_data.ahk"), "r", encoding="utf-8") as f:
        lib_txt = f.read()
    ae_blocks = re.findall(r'(_AE[A-Za-z0-9_]+)\(\)\s*\{(.*?)\n\}', lib_txt, re.S)
    if len(ae_blocks) < 61:
        errors.append(f"В lib/aslam_assets_data.ahk найдено {len(ae_blocks)} функций (ожидалось 61)")
    for fn_name, body in ae_blocks:
        parts = re.findall(r'"([A-Za-z0-9+/=]+)"', body)
        raw = base64.b64decode("".join(parts))
        if fn_name == "_AEwav":
            if raw[:4] != b"RIFF":
                errors.append(f"{fn_name}: неверная сигнатура WAV")
        else:
            if raw[:8] != b"\x89PNG\r\n\x1a\n":
                errors.append(f"{fn_name}: неверная сигнатура PNG")

    for acc in ["blue", "purple", "emerald", "orange", "pink", "cyan"]:
        for prefix in ["header_", "header_light_", "sidebar_", "sidebar_light_"]:
            p3d = os.path.join(ROOT, "assets", "3d", f"{prefix}{acc}.png")
            if not os.path.exists(p3d):
                errors.append(f"Отсутствует 3D-ассет: assets/3d/{prefix}{acc}.png")

    req_sounds = ["ok", "warn", "error", "alarm", "bell", "dice", "startup", "click", "toggle", "open", "close", "select", "scroll", "antilag"]
    for s in req_sounds:
        sp = os.path.join(ROOT, "assets", "sounds", f"{s}.wav")
        if not os.path.exists(sp):
            errors.append(f"Отсутствует звук: assets/sounds/{s}.wav")
        else:
            with wave.open(sp, "rb") as wf:
                if wf.getframerate() != 44100 or wf.getsampwidth() != 2:
                    warnings.append(f"Звук {s}.wav не 44.1kHz 16-bit")

    print(f"Проверено инструментов: {len(unique_tools)}")
    print(f"Встроенных Base64 ассетов: {len(ae_blocks)}")
    print(f"3D-шапок и панелей в assets/3d: {len(os.listdir(os.path.join(ROOT, 'assets', '3d')))}")
    print(f"Звуков в assets/sounds: {len(req_sounds)}")
    print(f"ОШИБОК: {len(errors)}  ·  ПРЕДУПРЕЖДЕНИЙ: {len(warnings)}")
    for e in errors:
        print("  [ERROR]", e)
    for w in warnings:
        print("  [WARN]", w)
    return 0 if not errors else 1

if __name__ == "__main__":
    sys.exit(check_project())
